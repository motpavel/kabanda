const DEFAULT_TIMEOUT_MS = 15_000;
const MIN_BOOTSTRAP_TTL_MS = 10_000;
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS', 'TRACE']);
const TRANSIENT_HTTP_STATUSES = new Set([408, 425, 429, 500, 502, 503, 504]);
const MAX_TRANSIENT_ATTEMPTS = 3;
const RETRY_BASE_MS = 100;
const RETRY_MAX_MS = 2_000;
const POLL_MAX_MS = 2_500;
const POLL_FAST_ATTEMPTS = 4;
const PENDING_DB_NAME = 'storage-relay-web';
const PENDING_DB_VERSION = 1;
const PENDING_STORE_NAME = 'pending-requests';
const PENDING_RECORD_VERSION = 1;
const REQUEST_RECOVERY_WINDOW_MS = 10 * 60_000;

export class StorageRelayError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'StorageRelayError';
    this.code = code;
    this.status = options.status ?? null;
  }
}

function bytesToBase64Url(bytes) {
  let binary = '';
  const chunkSize = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function base64UrlToBytes(value) {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
  const binary = atob(normalized + '='.repeat((4 - (normalized.length % 4)) % 4));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

function randomKey() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return { bytes, encoded: bytesToBase64Url(bytes) };
}

function abortError() {
  return new DOMException('The operation was aborted', 'AbortError');
}

function assertNotAborted(signal) {
  if (signal?.aborted) throw signal.reason ?? abortError();
}

function wait(ms, signal) {
  assertNotAborted(signal);
  return new Promise((resolve, reject) => {
    let timer;
    const cleanup = () => {
      if (timer !== undefined) clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
    };
    const abort = () => {
      cleanup();
      reject(signal.reason ?? abortError());
    };
    timer = setTimeout(() => {
      cleanup();
      resolve();
    }, ms);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
  });
}

function isOffline() {
  return typeof navigator !== 'undefined' && navigator.onLine === false;
}

function isHidden() {
  return typeof document !== 'undefined' && document.visibilityState === 'hidden';
}

function browserWindow() {
  return typeof window !== 'undefined' && typeof window.addEventListener === 'function'
    ? window
    : null;
}

function waitForCondition(predicate, subscriptions, signal) {
  assertNotAborted(signal);
  if (predicate()) return Promise.resolve();
  if (subscriptions.length === 0) return Promise.resolve();
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      subscriptions.forEach(([target, event]) => target.removeEventListener(event, check));
      signal?.removeEventListener('abort', abort);
    };
    const finish = callback => value => {
      if (settled) return;
      settled = true;
      cleanup();
      callback(value);
    };
    const done = finish(resolve);
    const fail = finish(reject);
    const check = () => {
      if (predicate()) done();
    };
    const abort = () => fail(signal.reason ?? abortError());
    subscriptions.forEach(([target, event]) => target.addEventListener(event, check));
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
    else check();
  });
}

function waitForOnline(signal) {
  if (!isOffline()) return Promise.resolve();
  const target = browserWindow();
  return waitForCondition(
    () => !isOffline(),
    target ? [[target, 'online']] : [],
    signal,
  );
}

function waitForPollingWindow(signal) {
  if (!isOffline() && !isHidden()) return Promise.resolve();
  const subscriptions = [];
  const target = browserWindow();
  if (target) subscriptions.push([target, 'online']);
  if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
    subscriptions.push([document, 'visibilitychange']);
  }
  return waitForCondition(() => !isOffline() && !isHidden(), subscriptions, signal);
}

function isTransientStatus(status) {
  return TRANSIENT_HTTP_STATUSES.has(Number(status));
}

function isTransientNetworkError(error) {
  if (error instanceof TypeError) return true;
  if (error?.name === 'NetworkError' || error?.name === 'TimeoutError') return true;
  return [
    'ECONNABORTED',
    'ECONNREFUSED',
    'ECONNRESET',
    'ENETDOWN',
    'ENETUNREACH',
    'ENOTFOUND',
    'ETIMEDOUT',
    'NETWORK_ERROR',
  ].includes(error?.code);
}

function retryAfterMs(response) {
  const value = response?.headers?.get?.('Retry-After');
  if (!value) return 0;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1_000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 0;
}

function jitter(value) {
  const spread = 0.8 + Math.random() * 0.4;
  return Math.max(1, Math.round(value * spread));
}

function transientDelay(attempt, response) {
  const exponential = Math.min(RETRY_MAX_MS, RETRY_BASE_MS * (2 ** attempt));
  return Math.min(RETRY_MAX_MS, Math.max(retryAfterMs(response), jitter(exponential)));
}

function pollDelay(interval, misses) {
  const stage = Math.floor(Math.max(0, misses - 1) / POLL_FAST_ATTEMPTS);
  return jitter(Math.min(POLL_MAX_MS, interval * (2 ** stage)));
}

async function cancelResponseBody(response) {
  try {
    await response?.body?.cancel?.();
  } catch {
    // A failed best-effort cancellation must not mask the retryable response.
  }
}

async function fetchWithTransientRetries(operation, signal, maxAttempts = MAX_TRANSIENT_ATTEMPTS) {
  for (let attempt = 0; ; attempt += 1) {
    assertNotAborted(signal);
    await waitForOnline(signal);
    try {
      const response = await raceWithSignal(operation, signal);
      if (!isTransientStatus(response.status) || attempt + 1 >= maxAttempts) return response;
      const delay = transientDelay(attempt, response);
      await cancelResponseBody(response);
      await wait(delay, signal);
    } catch (error) {
      assertNotAborted(signal);
      if (!isTransientNetworkError(error) || attempt + 1 >= maxAttempts) throw error;
      await wait(transientDelay(attempt), signal);
    }
  }
}

function raceWithSignal(operation, signal) {
  assertNotAborted(signal);
  if (!signal) return Promise.resolve().then(operation);
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => signal.removeEventListener('abort', abortListener);
    const finish = callback => value => {
      if (settled) return;
      settled = true;
      cleanup();
      callback(value);
    };
    const abort = finish(reject);
    const abortListener = () => abort(signal.reason ?? abortError());
    signal.addEventListener('abort', abortListener, { once: true });
    if (signal.aborted) abortListener();
    Promise.resolve()
      .then(operation)
      .then(finish(resolve), finish(reject));
  });
}

function normalizeTimeoutMs(value, fallback = DEFAULT_TIMEOUT_MS) {
  const timeoutMs = Number(value);
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) return fallback;
  return Math.max(1, timeoutMs);
}

function createAbortContext(externalSignal, timeoutMs) {
  const controller = new AbortController();
  const startedAt = Date.now();
  let timer;
  let timedOut = false;

  const abortFromExternal = () => {
    controller.abort(externalSignal.reason ?? abortError());
  };
  if (externalSignal?.aborted) abortFromExternal();
  else {
    externalSignal?.addEventListener('abort', abortFromExternal, { once: true });
    if (externalSignal?.aborted) abortFromExternal();
  }

  const setDeadline = deadline => {
    if (timer !== undefined) clearTimeout(timer);
    if (controller.signal.aborted) return;
    const remainingMs = deadline - Date.now();
    const timeout = () => {
      timedOut = true;
      controller.abort(new StorageRelayError('TIMEOUT', 'Storage Relay response timed out'));
    };
    if (remainingMs <= 0) timeout();
    else timer = setTimeout(timeout, remainingMs);
  };

  setDeadline(startedAt + normalizeTimeoutMs(timeoutMs));

  return {
    signal: controller.signal,
    startedAt,
    setTimeoutMs(value) {
      setDeadline(startedAt + normalizeTimeoutMs(value, timeoutMs));
    },
    normalizeError(error) {
      if (externalSignal?.aborted) return externalSignal.reason ?? abortError();
      if (timedOut) return new StorageRelayError('TIMEOUT', 'Storage Relay response timed out', {
        cause: error,
      });
      return error;
    },
    cleanup() {
      if (timer !== undefined) clearTimeout(timer);
      externalSignal?.removeEventListener('abort', abortFromExternal);
    },
  };
}

function normalizeUrl(input) {
  const value = input instanceof Request ? input.url : String(input);
  const url = new URL(value, 'https://storage-relay.invalid');
  if (url.username || url.password || url.hash) {
    throw new StorageRelayError('INVALID_URL', 'The request URL is not supported');
  }
  const query = {};
  for (const [name, value] of url.searchParams) {
    if (!(name in query)) query[name] = value;
    else if (Array.isArray(query[name])) query[name].push(value);
    else query[name] = [query[name], value];
  }
  return { path: url.pathname || '/', query };
}

function normalizeHeaders(input, requestInput) {
  const headers = new Headers(requestInput instanceof Request ? requestInput.headers : undefined);
  new Headers(input || {}).forEach((value, name) => headers.set(name, value));
  return Object.fromEntries(Array.from(headers.entries()).map(([name, value]) => [name.toLowerCase(), value]));
}

async function normalizeBody(body, headers) {
  if (body === undefined || body === null) {
    return { body_encoding: 'none', body: null };
  }
  if (typeof body === 'string') {
    const contentType = headers['content-type'] || '';
    if (contentType.includes('application/json') || contentType.includes('+json')) {
      try {
        return { body_encoding: 'json', body: JSON.parse(body) };
      } catch (error) {
        throw new StorageRelayError('INVALID_JSON', 'Request body is not valid JSON', { cause: error });
      }
    }
    return { body_encoding: 'text', body };
  }
  if (body instanceof URLSearchParams) {
    headers['content-type'] ||= 'application/x-www-form-urlencoded;charset=UTF-8';
    return { body_encoding: 'text', body: body.toString() };
  }
  if (Object.getPrototypeOf(body) === Object.prototype || Array.isArray(body)) {
    headers['content-type'] ||= 'application/json; charset=utf-8';
    return { body_encoding: 'json', body };
  }
  throw new StorageRelayError(
    'UNSUPPORTED_BODY',
    'Storage Relay v1 supports JSON, text and URLSearchParams request bodies',
  );
}

function validateBootstrapUrl(value, name, allowedStorageHosts) {
  let url;
  try {
    url = new URL(value);
  } catch (error) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', `${name} is not a valid URL`, {
      cause: error,
    });
  }
  if (url.protocol !== 'https:') {
    throw new StorageRelayError('INVALID_BOOTSTRAP', `${name} must use HTTPS`);
  }
  if (allowedStorageHosts && !allowedStorageHosts.has(url.hostname.toLowerCase())) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', `${name} host is not allowed`);
  }
}

function validateBootstrap(value, { expectedAppId, allowedStorageHosts } = {}) {
  if (
    !value ||
    value.specversion !== '1.0' ||
    typeof value.app_id !== 'string' ||
    typeof value.expires_at !== 'string' ||
    typeof value.outbox_base_url !== 'string' ||
    !value.inbox_upload?.url ||
    !value.inbox_upload?.fields
  ) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', 'Storage Relay bootstrap is invalid');
  }
  const deliveryMode = value.delivery_mode ?? 'polling';
  if (!['polling', 'object-trigger'].includes(deliveryMode)) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', 'Storage Relay delivery mode is invalid');
  }
  if (
    deliveryMode === 'polling' &&
    (!value.wakeup_upload?.url || !value.wakeup_upload?.fields)
  ) {
    throw new StorageRelayError(
      'INVALID_BOOTSTRAP',
      'Storage Relay polling bootstrap requires wakeup_upload',
    );
  }
  const expiresAt = Date.parse(value.expires_at);
  if (!Number.isFinite(expiresAt)) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', 'Storage Relay bootstrap expiry is invalid');
  }
  if (expiresAt <= Date.now()) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', 'Storage Relay bootstrap has expired');
  }
  if (expectedAppId && value.app_id !== expectedAppId) {
    throw new StorageRelayError('INVALID_BOOTSTRAP', 'Storage Relay bootstrap app_id does not match');
  }
  validateBootstrapUrl(value.outbox_base_url, 'outbox_base_url', allowedStorageHosts);
  validateBootstrapUrl(value.inbox_upload.url, 'inbox_upload.url', allowedStorageHosts);
  if (value.wakeup_upload) {
    validateBootstrapUrl(value.wakeup_upload.url, 'wakeup_upload.url', allowedStorageHosts);
  }
  return { ...value, delivery_mode: deliveryMode, expiresAt };
}

function normalizeAllowedStorageHosts(value) {
  if (value === undefined) return null;
  if (!Array.isArray(value) || value.length === 0) {
    throw new StorageRelayError(
      'INVALID_CONFIG',
      'allowedStorageHosts must be a non-empty array when provided',
    );
  }
  const hosts = new Set();
  for (const entry of value) {
    const host = String(entry || '').trim().toLowerCase();
    if (!host || host.includes('/') || host.includes(':')) {
      throw new StorageRelayError(
        'INVALID_CONFIG',
        'allowedStorageHosts entries must be hostnames without a scheme or path',
      );
    }
    hosts.add(host);
  }
  return hosts;
}

class PendingRequestStore {
  constructor() {
    this.memory = new Map();
    this.dbPromise = null;
    this.disabled = false;
    this.cleanupPromise = null;
  }

  async open() {
    if (this.disabled || typeof globalThis.indexedDB?.open !== 'function') return null;
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise(resolve => {
      let request;
      try {
        request = globalThis.indexedDB.open(PENDING_DB_NAME, PENDING_DB_VERSION);
      } catch {
        this.disabled = true;
        resolve(null);
        return;
      }
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(PENDING_STORE_NAME)) {
          database.createObjectStore(PENDING_STORE_NAME, { keyPath: 'key' });
        }
      };
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => database.close();
        resolve(database);
      };
      request.onerror = () => {
        this.disabled = true;
        resolve(null);
      };
      request.onblocked = () => resolve(null);
    });
    return this.dbPromise;
  }

  async run(mode, action) {
    const database = await this.open();
    if (!database) return { ok: false, value: undefined };
    return new Promise(resolve => {
      let settled = false;
      const finish = value => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      try {
        const transaction = database.transaction(PENDING_STORE_NAME, mode);
        const request = action(transaction.objectStore(PENDING_STORE_NAME));
        if (!request) {
          finish({ ok: false, value: undefined });
          return;
        }
        request.onsuccess = () => finish({ ok: true, value: request.result });
        request.onerror = () => finish({ ok: false, value: undefined });
        transaction.onabort = () => finish({ ok: false, value: undefined });
      } catch {
        finish({ ok: false, value: undefined });
      }
    });
  }

  async cleanupExpired() {
    const now = Date.now();
    for (const [key, record] of this.memory) {
      if (Date.parse(record?.expires_at) <= now) this.memory.delete(key);
    }
    const result = await this.run(
      'readonly',
      store => typeof store.getAll === 'function' ? store.getAll() : null,
    );
    if (!result.ok || !Array.isArray(result.value)) return;
    const expiredKeys = result.value
      .filter(record => Date.parse(record?.expires_at) <= now)
      .map(record => record.key)
      .filter(Boolean);
    await Promise.all(expiredKeys.map(key => this.delete(key)));
  }

  ensureCleanup() {
    if (!this.cleanupPromise) {
      this.cleanupPromise = this.cleanupExpired().catch(() => {});
    }
    return this.cleanupPromise;
  }

  async get(key) {
    await this.ensureCleanup();
    if (this.memory.has(key)) return this.memory.get(key);
    const result = await this.run('readonly', store => store.get(key));
    if (!result.ok || !result.value) return null;
    this.memory.set(key, result.value);
    return result.value;
  }

  async put(record) {
    this.memory.set(record.key, record);
    await this.run('readwrite', store => store.put(record));
  }

  async delete(key) {
    this.memory.delete(key);
    await this.run('readwrite', store => store.delete(key));
  }
}

function pendingRecordKey(bootstrapUrl, idempotencyKey) {
  return `${bootstrapUrl}\n${idempotencyKey}`;
}

function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && Object.getPrototypeOf(value) === Object.prototype) {
    const entries = Object.keys(value)
      .filter(key => value[key] !== undefined)
      .sort()
      .map(key => `${JSON.stringify(key)}:${canonicalJson(value[key])}`);
    return `{${entries.join(',')}}`;
  }
  return JSON.stringify(value);
}

function matchesPendingRequest(record, {
  method,
  path,
  query,
  headers,
  normalizedBody,
}) {
  const envelope = record?.request_envelope;
  const semanticHeaders = value => Object.fromEntries(
    Object.entries(value || {}).filter(
      ([name]) => !['idempotency-key', 'x-request-id'].includes(name.toLowerCase()),
    ),
  );
  return envelope?.method === method
    && envelope?.path === path
    && canonicalJson(envelope?.query || {}) === canonicalJson(query || {})
    && envelope?.body_encoding === normalizedBody.body_encoding
    && canonicalJson(envelope?.body) === canonicalJson(normalizedBody.body)
    && canonicalJson(semanticHeaders(envelope?.headers)) === canonicalJson(semanticHeaders(headers));
}

function pendingBootstrap(record, { expectedAppId, allowedStorageHosts }) {
  if (
    !record ||
    record.version !== PENDING_RECORD_VERSION ||
    typeof record.app_id !== 'string' ||
    typeof record.request_id !== 'string' ||
    typeof record.reply_key !== 'string' ||
    typeof record.outbox_base_url !== 'string' ||
    typeof record.expires_at !== 'string' ||
    !['prepared', 'dispatched'].includes(record.state) ||
    !record.request_envelope ||
    record.request_envelope.request_id !== record.request_id ||
    record.request_envelope.app_id !== record.app_id
  ) {
    return null;
  }
  const expiresAt = Date.parse(record.expires_at);
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return null;
  let replyKey;
  try {
    replyKey = base64UrlToBytes(record.reply_key);
  } catch {
    return null;
  }
  if (replyKey.length !== 32) return null;
  if (expectedAppId && record.app_id !== expectedAppId) return null;
  try {
    validateBootstrapUrl(record.outbox_base_url, 'outbox_base_url', allowedStorageHosts);
  } catch {
    return null;
  }
  return {
    bootstrap: {
      app_id: record.app_id,
      outbox_base_url: record.outbox_base_url,
      poll_interval_ms: record.poll_interval_ms,
      request_timeout_ms: record.request_timeout_ms,
    },
    expiresAt,
    replyKey,
  };
}

function shouldDiscardPending(error) {
  if (!(error instanceof StorageRelayError)) return false;
  if (error.code === 'RESPONSE_FAILED') return !isTransientStatus(error.status);
  return [
    'DECRYPT_FAILED',
    'INVALID_RESPONSE',
    'PENDING_APP_MISMATCH',
    'RESPONSE_MISMATCH',
  ].includes(error.code);
}

async function uploadForm(fetchImpl, specification, payload, filename, signal) {
  const form = new FormData();
  Object.entries(specification.fields).forEach(([name, value]) => form.append(name, value));
  form.append(
    'file',
    new Blob([JSON.stringify(payload)], { type: 'application/json' }),
    filename,
  );
  const response = await fetchWithTransientRetries(
    () => fetchImpl(specification.url, {
      method: 'POST',
      mode: 'cors',
      credentials: 'omit',
      body: form,
      signal,
    }),
    signal,
  );
  if (!response.ok) {
    throw new StorageRelayError('UPLOAD_FAILED', `Object Storage upload failed with HTTP ${response.status}`, {
      status: response.status,
    });
  }
}

async function uploadRequest(fetchImpl, bootstrap, requestEnvelope, signal) {
  await uploadForm(
    fetchImpl,
    bootstrap.inbox_upload,
    requestEnvelope,
    `${requestEnvelope.request_id}.json`,
    signal,
  );
  if (bootstrap.delivery_mode === 'object-trigger') return;
  await uploadForm(
    fetchImpl,
    bootstrap.wakeup_upload,
    {
      specversion: '1.0',
      app_id: bootstrap.app_id,
      request_id: requestEnvelope.request_id,
      created_at: new Date().toISOString(),
    },
    'wakeup.json',
    signal,
  );
}

export async function decryptResponseEnvelope(envelope, replyKey) {
  if (
    !envelope ||
    envelope.specversion !== '1.0' ||
    envelope.algorithm !== 'A256GCM' ||
    typeof envelope.request_id !== 'string' ||
    typeof envelope.app_id !== 'string'
  ) {
    throw new StorageRelayError('INVALID_RESPONSE', 'Encrypted response envelope is invalid');
  }
  const key = await crypto.subtle.importKey('raw', replyKey, { name: 'AES-GCM' }, false, ['decrypt']);
  const aad = new TextEncoder().encode(
    `storage-relay-v1:${envelope.app_id}:${envelope.request_id}`,
  );
  try {
    const plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: base64UrlToBytes(envelope.iv), additionalData: aad },
      key,
      base64UrlToBytes(envelope.ciphertext),
    );
    return JSON.parse(new TextDecoder().decode(plaintext));
  } catch (error) {
    throw new StorageRelayError('DECRYPT_FAILED', 'Storage Relay response could not be decrypted', {
      cause: error,
    });
  }
}

function toBrowserResponse(payload) {
  if (!Number.isInteger(payload.status) || payload.status < 100 || payload.status > 599) {
    throw new StorageRelayError('INVALID_RESPONSE', 'Decrypted response status is invalid');
  }
  let body = null;
  if (payload.body_encoding === 'json') body = JSON.stringify(payload.body);
  else if (payload.body_encoding === 'text') body = String(payload.body ?? '');
  else if (payload.body_encoding !== 'none') {
    throw new StorageRelayError('INVALID_RESPONSE', 'Decrypted response body encoding is invalid');
  }
  if ([204, 205, 304].includes(payload.status)) body = null;
  const headers = new Headers(payload.headers || {});
  headers.set('X-Storage-Relay', '1.0');
  if (payload.request_id) headers.set('X-Storage-Relay-Request-Id', payload.request_id);
  return new Response(body, { status: payload.status, headers });
}

export class StorageRelayClient {
  constructor({
    bootstrapUrl,
    fetchImpl = globalThis.fetch,
    timeoutMs = DEFAULT_TIMEOUT_MS,
    expectedAppId,
    allowedStorageHosts,
  } = {}) {
    if (!bootstrapUrl || typeof bootstrapUrl !== 'string') {
      throw new StorageRelayError('INVALID_CONFIG', 'bootstrapUrl is required');
    }
    let parsedBootstrapUrl;
    try {
      parsedBootstrapUrl = new URL(bootstrapUrl);
    } catch (error) {
      throw new StorageRelayError('INVALID_CONFIG', 'bootstrapUrl must be a valid HTTPS URL', {
        cause: error,
      });
    }
    if (parsedBootstrapUrl.protocol !== 'https:') {
      throw new StorageRelayError('INVALID_CONFIG', 'bootstrapUrl must use HTTPS');
    }
    if (typeof fetchImpl !== 'function') {
      throw new StorageRelayError('INVALID_CONFIG', 'fetch implementation is required');
    }
    this.bootstrapUrl = bootstrapUrl;
    // Native window.fetch requires the Window receiver in some browsers.  Keeping
    // the original function in a closure avoids accidentally calling it as a
    // StorageRelayClient method (which results in "Illegal invocation").
    this.fetchImpl = (...args) => fetchImpl(...args);
    this.timeoutMs = normalizeTimeoutMs(timeoutMs);
    this.expectedAppId = expectedAppId ? String(expectedAppId) : null;
    this.allowedStorageHosts = normalizeAllowedStorageHosts(allowedStorageHosts);
    this.bootstrapCache = null;
    this.bootstrapInFlight = null;
    this.pendingStore = new PendingRequestStore();
  }

  async loadBootstrap({ force = false, signal } = {}) {
    assertNotAborted(signal);
    if (
      !force &&
      this.bootstrapCache &&
      this.bootstrapCache.expiresAt - Date.now() > MIN_BOOTSTRAP_TTL_MS
    ) {
      return this.bootstrapCache;
    }
    if (!this.bootstrapInFlight) {
      const operationContext = createAbortContext(
        null,
        Math.max(DEFAULT_TIMEOUT_MS, this.timeoutMs),
      );
      const operation = (async () => {
        try {
          const response = await fetchWithTransientRetries(
            () => this.fetchImpl(`${this.bootstrapUrl}?t=${Date.now()}`, {
              mode: 'cors',
              cache: 'no-store',
              credentials: 'omit',
              signal: operationContext.signal,
            }),
            operationContext.signal,
          );
          if (!response.ok) {
            throw new StorageRelayError(
              'BOOTSTRAP_FAILED',
              `Storage Relay bootstrap failed with HTTP ${response.status}`,
              { status: response.status },
            );
          }
          this.bootstrapCache = validateBootstrap(
            await raceWithSignal(() => response.json(), operationContext.signal),
            {
              expectedAppId: this.expectedAppId,
              allowedStorageHosts: this.allowedStorageHosts,
            },
          );
          return this.bootstrapCache;
        } catch (error) {
          throw operationContext.normalizeError(error);
        } finally {
          operationContext.cleanup();
        }
      })();
      let shared;
      shared = operation.finally(() => {
        if (this.bootstrapInFlight === shared) this.bootstrapInFlight = null;
      });
      this.bootstrapInFlight = shared;
    }
    return raceWithSignal(() => this.bootstrapInFlight, signal);
  }

  async dispatch(bootstrap, requestEnvelope, signal) {
    try {
      await uploadRequest(this.fetchImpl, bootstrap, requestEnvelope, signal);
      return bootstrap;
    } catch (error) {
      if (!(error instanceof StorageRelayError) || error.status !== 403) throw error;
      const refreshed = await this.loadBootstrap({ force: true, signal });
      await uploadRequest(this.fetchImpl, refreshed, requestEnvelope, signal);
      return refreshed;
    }
  }

  async awaitResponse(bootstrap, requestId, replyKey, deadline, signal) {
    const url = `${bootstrap.outbox_base_url}/${requestId}.json`;
    const interval = Math.max(75, Number(bootstrap.poll_interval_ms) || 150);
    let misses = 0;
    let transientFailures = 0;
    while (Date.now() < deadline) {
      assertNotAborted(signal);
      await waitForPollingWindow(signal);
      if (Date.now() >= deadline) break;
      let response;
      try {
        response = await raceWithSignal(
          () => this.fetchImpl(`${url}?t=${Date.now()}`, {
            mode: 'cors',
            cache: 'no-store',
            credentials: 'omit',
            signal,
          }),
          signal,
        );
      } catch (error) {
        assertNotAborted(signal);
        transientFailures += 1;
        if (!isTransientNetworkError(error) || transientFailures >= MAX_TRANSIENT_ATTEMPTS) {
          throw error;
        }
        const remaining = deadline - Date.now();
        if (remaining <= 0) break;
        await wait(Math.min(remaining, transientDelay(transientFailures - 1)), signal);
        continue;
      }
      if (response.ok) {
        const envelope = await raceWithSignal(() => response.json(), signal);
        if (envelope.request_id !== requestId || envelope.app_id !== bootstrap.app_id) {
          throw new StorageRelayError('RESPONSE_MISMATCH', 'Storage Relay response identity does not match');
        }
        return toBrowserResponse(await decryptResponseEnvelope(envelope, replyKey));
      }
      if (response.status === 404) {
        transientFailures = 0;
        misses += 1;
        const remaining = deadline - Date.now();
        if (remaining <= 0) break;
        await wait(Math.min(remaining, pollDelay(interval, misses)), signal);
        continue;
      }
      if (isTransientStatus(response.status)) {
        transientFailures += 1;
        if (transientFailures < MAX_TRANSIENT_ATTEMPTS) {
          const delay = transientDelay(transientFailures - 1, response);
          await cancelResponseBody(response);
          const remaining = deadline - Date.now();
          if (remaining <= 0) break;
          await wait(Math.min(remaining, delay), signal);
          continue;
        }
      }
      throw new StorageRelayError(
        'RESPONSE_FAILED',
        `Storage Relay response lookup failed with HTTP ${response.status}`,
        { status: response.status },
      );
    }
    throw new StorageRelayError('TIMEOUT', 'Storage Relay response timed out');
  }

  async fetch(input, init = {}) {
    const requestInput = input instanceof Request ? input : null;
    const externalSignal = init.signal || requestInput?.signal;
    assertNotAborted(externalSignal);
    const initialTimeoutMs = normalizeTimeoutMs(init.timeoutMs, this.timeoutMs);
    const abortContext = createAbortContext(externalSignal, initialTimeoutMs);
    let pendingKey = null;

    try {
      const { path, query } = normalizeUrl(input);
      const method = String(init.method || requestInput?.method || 'GET').toUpperCase();
      const headers = normalizeHeaders(init.headers, requestInput);
      let rawBody = init.body;
      if (rawBody === undefined && requestInput && !['GET', 'HEAD'].includes(method)) {
        rawBody = await requestInput.clone().text();
      }
      const normalizedBody = await normalizeBody(rawBody, headers);
      const generatedRequestId = crypto.randomUUID();
      const idempotencyKey = String(
        init.idempotencyKey || headers['idempotency-key'] || generatedRequestId,
      );
      const persistPending = !SAFE_METHODS.has(method);
      if (persistPending) headers['idempotency-key'] = idempotencyKey;
      pendingKey = persistPending
        ? pendingRecordKey(this.bootstrapUrl, idempotencyKey)
        : null;

      let pending = pendingKey
        ? await raceWithSignal(() => this.pendingStore.get(pendingKey), abortContext.signal)
        : null;
      let restored = pendingBootstrap(pending, {
        expectedAppId: this.expectedAppId,
        allowedStorageHosts: this.allowedStorageHosts,
      });
      if (pending && !restored) {
        await this.pendingStore.delete(pendingKey);
        pending = null;
      }
      if (pending && !matchesPendingRequest(pending, {
        method,
        path,
        query,
        headers,
        normalizedBody,
      })) {
        throw new StorageRelayError(
          'IDEMPOTENCY_CONFLICT',
          'The Idempotency-Key already belongs to another pending request',
        );
      }

      if (pending && restored) {
        const timeoutMs = init.timeoutMs === undefined
          ? normalizeTimeoutMs(pending.request_timeout_ms, this.timeoutMs)
          : initialTimeoutMs;
        abortContext.setTimeoutMs(timeoutMs);
        const deadline = abortContext.startedAt + timeoutMs;
        let activeBootstrap = restored.bootstrap;
        if (pending.state === 'prepared') {
          const freshBootstrap = await this.loadBootstrap({ signal: abortContext.signal });
          if (freshBootstrap.app_id !== pending.app_id) {
            throw new StorageRelayError(
              'PENDING_APP_MISMATCH',
              'The pending request belongs to a different relay application',
            );
          }
          activeBootstrap = await this.dispatch(
            freshBootstrap,
            pending.request_envelope,
            abortContext.signal,
          );
          pending = {
            ...pending,
            state: 'dispatched',
            outbox_base_url: activeBootstrap.outbox_base_url,
            poll_interval_ms: activeBootstrap.poll_interval_ms,
          };
          await raceWithSignal(() => this.pendingStore.put(pending), abortContext.signal);
          restored = pendingBootstrap(pending, {
            expectedAppId: this.expectedAppId,
            allowedStorageHosts: this.allowedStorageHosts,
          });
        }
        const response = await this.awaitResponse(
          activeBootstrap,
          pending.request_id,
          restored.replyKey,
          deadline,
          abortContext.signal,
        );
        await this.pendingStore.delete(pendingKey);
        return response;
      }

      const bootstrap = await this.loadBootstrap({ signal: abortContext.signal });
      const timeoutMs = init.timeoutMs === undefined
        ? normalizeTimeoutMs(bootstrap.request_timeout_ms, this.timeoutMs)
        : initialTimeoutMs;
      abortContext.setTimeoutMs(timeoutMs);
      assertNotAborted(abortContext.signal);

      const requestId = generatedRequestId;
      const replyKey = randomKey();
      const now = new Date();
      const deadline = abortContext.startedAt + timeoutMs;
      // Keep the durable mutation identity available long enough for the
      // bounded maintenance reconciler to repair a missed trigger. The caller
      // still gets its normal short timeout; only an explicit retry with the
      // same Idempotency-Key resumes this record.
      const requestExpiresAt = new Date(
        now.getTime() + REQUEST_RECOVERY_WINDOW_MS,
      ).toISOString();
      const requestEnvelope = {
        specversion: '1.0',
        request_id: requestId,
        app_id: bootstrap.app_id,
        method,
        path,
        headers,
        query,
        ...normalizedBody,
        idempotency_key: idempotencyKey,
        reply_key: replyKey.encoded,
        created_at: now.toISOString(),
        expires_at: requestExpiresAt,
      };
      let pendingRecord = {
        key: pendingKey,
        version: PENDING_RECORD_VERSION,
        state: 'prepared',
        request_id: requestId,
        app_id: bootstrap.app_id,
        idempotency_key: idempotencyKey,
        reply_key: replyKey.encoded,
        outbox_base_url: bootstrap.outbox_base_url,
        poll_interval_ms: bootstrap.poll_interval_ms,
        request_timeout_ms: timeoutMs,
        created_at: now.toISOString(),
        expires_at: requestExpiresAt,
        request_envelope: requestEnvelope,
      };
      if (pendingKey) {
        await raceWithSignal(() => this.pendingStore.put(pendingRecord), abortContext.signal);
      }
      const activeBootstrap = await this.dispatch(
        bootstrap,
        requestEnvelope,
        abortContext.signal,
      );
      pendingRecord = {
        ...pendingRecord,
        state: 'dispatched',
        outbox_base_url: activeBootstrap.outbox_base_url,
        poll_interval_ms: activeBootstrap.poll_interval_ms,
      };
      if (pendingKey) {
        await raceWithSignal(() => this.pendingStore.put(pendingRecord), abortContext.signal);
      }
      const response = await this.awaitResponse(
        activeBootstrap,
        requestId,
        replyKey.bytes,
        deadline,
        abortContext.signal,
      );
      if (pendingKey) await this.pendingStore.delete(pendingKey);
      return response;
    } catch (error) {
      if (pendingKey && shouldDiscardPending(error)) {
        await this.pendingStore.delete(pendingKey);
      }
      throw abortContext.normalizeError(error);
    } finally {
      abortContext.cleanup();
    }
  }
}

export function createStorageRelayFetch(options) {
  const client = new StorageRelayClient(options);
  const relayFetch = client.fetch.bind(client);
  relayFetch.client = client;
  return relayFetch;
}
