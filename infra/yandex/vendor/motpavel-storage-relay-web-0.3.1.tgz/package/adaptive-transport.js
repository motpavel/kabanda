import { StorageRelayClient, StorageRelayError } from './storage-relay.js';

const MODES = new Set(['auto', 'direct', 'relay']);
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS', 'TRACE']);
const DEFAULT_PROBE_TIMEOUT_MS = 1_500;
const DEFAULT_PROBE_TTL_MS = 30_000;
const DEFAULT_DIRECT_TIMEOUT_MS = 5_000;

export class AdaptiveTransportError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'AdaptiveTransportError';
    this.code = code;
  }
}

function abortError() {
  return new DOMException('The operation was aborted', 'AbortError');
}

function assertNotAborted(signal) {
  if (signal?.aborted) throw signal.reason ?? abortError();
}

function positiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function validateMode(mode) {
  if (!MODES.has(mode)) {
    throw new AdaptiveTransportError(
      'INVALID_MODE',
      `Adaptive transport mode must be one of: ${Array.from(MODES).join(', ')}`,
    );
  }
  return mode;
}

function raceWithSignal(operation, signal) {
  assertNotAborted(signal);
  if (!signal) return Promise.resolve().then(operation);
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => signal.removeEventListener('abort', abortListener);
    const finish = callback => value => {
      if (settled) return;
      settled = true;
      cleanup();
      callback(value);
    };
    const abort = finish(reject);
    const abortListener = () => abort(signal.reason ?? abortError());
    signal.addEventListener('abort', abortListener, { once: true });
    if (signal.aborted) abortListener();
    Promise.resolve()
      .then(operation)
      .then(finish(resolve), finish(reject));
  });
}

async function fetchWithTimeout(fetchImpl, input, init, externalSignal, timeoutMs, label) {
  assertNotAborted(externalSignal);
  const controller = new AbortController();
  let timedOut = false;
  const abortFromExternal = () => controller.abort(externalSignal.reason ?? abortError());
  if (externalSignal?.aborted) abortFromExternal();
  else externalSignal?.addEventListener('abort', abortFromExternal, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort(
      new AdaptiveTransportError('DIRECT_TIMEOUT', `${label} timed out`),
    );
  }, positiveNumber(timeoutMs, DEFAULT_DIRECT_TIMEOUT_MS));

  try {
    return await raceWithSignal(
      () => fetchImpl(input, { ...init, signal: controller.signal }),
      controller.signal,
    );
  } catch (error) {
    if (externalSignal?.aborted) throw externalSignal.reason ?? abortError();
    if (timedOut) {
      throw new AdaptiveTransportError('DIRECT_TIMEOUT', `${label} timed out`, { cause: error });
    }
    throw error;
  } finally {
    clearTimeout(timer);
    externalSignal?.removeEventListener('abort', abortFromExternal);
  }
}

function isNetworkFailure(error) {
  if (error instanceof TypeError) return true;
  if (error?.name === 'NetworkError' || error?.name === 'TimeoutError') return true;
  return [
    'ECONNABORTED',
    'ECONNREFUSED',
    'ECONNRESET',
    'ENETDOWN',
    'ENETUNREACH',
    'ENOTFOUND',
    'ETIMEDOUT',
    'NETWORK_ERROR',
  ].includes(error?.code);
}

function canFallback(error) {
  return error instanceof AdaptiveTransportError && error.code === 'DIRECT_TIMEOUT'
    ? true
    : isNetworkFailure(error);
}

function browserIsOffline() {
  return typeof navigator !== 'undefined' && navigator.onLine === false;
}

function browserIsHidden() {
  return typeof document !== 'undefined' && document.visibilityState === 'hidden';
}

function browserConnection() {
  if (typeof navigator === 'undefined') return null;
  return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null;
}

function resolveUrl(input, baseUrl) {
  if (!baseUrl || input instanceof Request || input instanceof URL) return input;
  const value = String(input);
  try {
    return new URL(value).toString();
  } catch {
    const base = baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/`;
    return new URL(value, base).toString();
  }
}

function mergedHeaders(input, initHeaders) {
  const headers = new Headers(input instanceof Request ? input.headers : undefined);
  new Headers(initHeaders || {}).forEach((value, name) => headers.set(name, value));
  return headers;
}

function nativeRequestInit(init, headers, signal) {
  const {
    directTimeoutMs: _directTimeoutMs,
    idempotencyKey: _idempotencyKey,
    timeoutMs: _timeoutMs,
    transportMode: _transportMode,
    ...nativeInit
  } = init;
  return { ...nativeInit, headers, signal };
}

function relayRequestInit(init, headers, signal, idempotencyKey) {
  const {
    directTimeoutMs: _directTimeoutMs,
    transportMode: _transportMode,
    ...relayInit
  } = init;
  return {
    ...relayInit,
    headers,
    signal,
    ...(idempotencyKey ? { idempotencyKey } : {}),
  };
}

export class AdaptiveTransport {
  constructor({
    mode = 'auto',
    directBaseUrl = '',
    probeUrl,
    probeMethod = 'HEAD',
    probeTimeoutMs = DEFAULT_PROBE_TIMEOUT_MS,
    probeTtlMs = DEFAULT_PROBE_TTL_MS,
    directTimeoutMs = DEFAULT_DIRECT_TIMEOUT_MS,
    probeRequestInit = {},
    fetchImpl = globalThis.fetch,
    relayClient,
    relayOptions,
  } = {}) {
    if (typeof fetchImpl !== 'function') {
      throw new AdaptiveTransportError('INVALID_CONFIG', 'fetch implementation is required');
    }
    if (!relayClient && !relayOptions) {
      throw new AdaptiveTransportError(
        'INVALID_CONFIG',
        'relayClient or relayOptions is required',
      );
    }
    this.mode = validateMode(mode);
    this.directBaseUrl = String(directBaseUrl || '');
    this.probeUrl = probeUrl || this.directBaseUrl;
    this.probeMethod = String(probeMethod || 'HEAD').toUpperCase();
    this.probeTimeoutMs = positiveNumber(probeTimeoutMs, DEFAULT_PROBE_TIMEOUT_MS);
    this.probeTtlMs = positiveNumber(probeTtlMs, DEFAULT_PROBE_TTL_MS);
    this.directTimeoutMs = positiveNumber(directTimeoutMs, DEFAULT_DIRECT_TIMEOUT_MS);
    this.probeRequestInit = { ...probeRequestInit };
    this.fetchImpl = (...args) => fetchImpl(...args);
    this.relayClient = relayClient || new StorageRelayClient({
      ...relayOptions,
      fetchImpl: relayOptions.fetchImpl || fetchImpl,
    });
    if (typeof this.relayClient.fetch !== 'function') {
      throw new AdaptiveTransportError('INVALID_CONFIG', 'relayClient.fetch is required');
    }
    this.reachabilityCache = null;
    this.probeGeneration = 0;
    this.probeInFlight = null;
    this.installRouteRechecks();
  }

  setMode(mode) {
    const nextMode = validateMode(mode);
    if (nextMode !== this.mode) this.clearProbeCache();
    this.mode = nextMode;
    return this;
  }

  getMode() {
    return this.mode;
  }

  clearProbeCache() {
    this.reachabilityCache = null;
    this.probeGeneration += 1;
    this.probeInFlight = null;
  }

  cacheReachability(reachable, generation = this.probeGeneration) {
    if (generation !== this.probeGeneration) return;
    this.reachabilityCache = {
      reachable,
      expiresAt: Date.now() + this.probeTtlMs,
    };
  }

  installRouteRechecks() {
    const target = typeof window !== 'undefined' && typeof window.addEventListener === 'function'
      ? window
      : null;
    if (!target) return;
    const warm = () => {
      this.clearProbeCache();
      if (this.mode !== 'auto' || browserIsOffline() || browserIsHidden()) return;
      void this.probeDirect({ force: true }).catch(() => {});
    };
    target.addEventListener('online', warm);
    target.addEventListener('offline', () => {
      this.clearProbeCache();
      this.cacheReachability(false);
    });
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
      document.addEventListener('visibilitychange', () => {
        if (!browserIsHidden()) warm();
      });
    }
    const connection = browserConnection();
    connection?.addEventListener?.('change', warm);
  }

  async probeDirect({ force = false, signal } = {}) {
    assertNotAborted(signal);
    if (browserIsOffline()) {
      this.cacheReachability(false);
      return false;
    }
    if (force) this.reachabilityCache = null;
    if (
      this.reachabilityCache &&
      this.reachabilityCache.expiresAt > Date.now()
    ) {
      return this.reachabilityCache.reachable;
    }
    if (!this.probeUrl) {
      throw new AdaptiveTransportError(
        'INVALID_CONFIG',
        'probeUrl or directBaseUrl is required in auto mode',
      );
    }
    if (!this.probeInFlight) {
      const generation = this.probeGeneration;
      const probeTarget = resolveUrl(this.probeUrl, this.directBaseUrl);
      const operation = (async () => {
        try {
          await fetchWithTimeout(
            this.fetchImpl,
            probeTarget,
            {
              cache: 'no-store',
              credentials: 'omit',
              ...this.probeRequestInit,
              method: this.probeMethod,
            },
            null,
            this.probeTimeoutMs,
            'Direct API reachability probe',
          );
          // Any HTTP response, including 4xx/5xx, proves that the direct host is reachable.
          this.cacheReachability(true, generation);
          return true;
        } catch (error) {
          if (!canFallback(error)) throw error;
          this.cacheReachability(false, generation);
          return false;
        }
      })();
      let shared;
      shared = operation.finally(() => {
        if (this.probeInFlight === shared) this.probeInFlight = null;
      });
      this.probeInFlight = shared;
    }
    return raceWithSignal(() => this.probeInFlight, signal);
  }

  async fetch(input, init = {}) {
    const requestInput = input instanceof Request ? input : null;
    const signal = init.signal || requestInput?.signal;
    assertNotAborted(signal);
    const mode = validateMode(init.transportMode || this.mode);
    const method = String(init.method || requestInput?.method || 'GET').toUpperCase();
    const headers = mergedHeaders(requestInput, init.headers);
    const requestId = headers.get('X-Request-Id') || crypto.randomUUID();
    headers.set('X-Request-Id', requestId);

    let idempotencyKey = null;
    if (!SAFE_METHODS.has(method)) {
      idempotencyKey = String(
        init.idempotencyKey || headers.get('Idempotency-Key') || requestId,
      );
      headers.set('Idempotency-Key', idempotencyKey);
    }

    // Clone before attempting direct fetch: native fetch consumes Request bodies,
    // while a network timeout may still require the same mutation to go via relay.
    const directInput = requestInput ? requestInput.clone() : input;
    const relayInput = requestInput ? requestInput.clone() : input;
    const directTarget = resolveUrl(directInput, this.directBaseUrl);
    const directInit = nativeRequestInit(init, headers, signal);
    const relayInit = relayRequestInit(init, headers, signal, idempotencyKey);

    if (mode === 'relay') return this.relayClient.fetch(relayInput, relayInit);
    if (mode === 'direct') {
      return fetchWithTimeout(
        this.fetchImpl,
        directTarget,
        directInit,
        signal,
        positiveNumber(init.directTimeoutMs, this.directTimeoutMs),
        'Direct API request',
      );
    }

    const reachable = await this.probeDirect({ signal });
    if (!reachable) return this.relayClient.fetch(relayInput, relayInit);

    try {
      const response = await fetchWithTimeout(
        this.fetchImpl,
        directTarget,
        directInit,
        signal,
        positiveNumber(init.directTimeoutMs, this.directTimeoutMs),
        'Direct API request',
      );
      this.cacheReachability(true);
      return response;
    } catch (error) {
      if (!canFallback(error)) throw error;
      this.cacheReachability(false);
      return this.relayClient.fetch(relayInput, relayInit);
    }
  }
}

export function createAdaptiveFetch(options) {
  const transport = new AdaptiveTransport(options);
  const adaptiveFetch = transport.fetch.bind(transport);
  adaptiveFetch.transport = transport;
  return adaptiveFetch;
}

export { StorageRelayError };
