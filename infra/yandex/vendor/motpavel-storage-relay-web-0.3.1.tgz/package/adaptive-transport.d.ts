import type {
  StorageRelayClient,
  StorageRelayOptions,
  StorageRelayRequestInit,
} from './storage-relay.js';

export type AdaptiveTransportMode = 'auto' | 'direct' | 'relay';

export interface AdaptiveTransportOptions {
  mode?: AdaptiveTransportMode;
  directBaseUrl?: string;
  probeUrl?: string | URL;
  probeMethod?: string;
  probeTimeoutMs?: number;
  probeTtlMs?: number;
  directTimeoutMs?: number;
  probeRequestInit?: RequestInit;
  fetchImpl?: typeof fetch;
  relayClient?: Pick<StorageRelayClient, 'fetch'>;
  relayOptions?: StorageRelayOptions;
}

export type AdaptiveTransportRequestInit = StorageRelayRequestInit & {
  transportMode?: AdaptiveTransportMode;
  directTimeoutMs?: number;
};

export class AdaptiveTransportError extends Error {
  code: string;
}

export class AdaptiveTransport {
  constructor(options: AdaptiveTransportOptions);
  setMode(mode: AdaptiveTransportMode): this;
  getMode(): AdaptiveTransportMode;
  clearProbeCache(): void;
  probeDirect(options?: { force?: boolean; signal?: AbortSignal }): Promise<boolean>;
  fetch(input: RequestInfo | URL, init?: AdaptiveTransportRequestInit): Promise<Response>;
}

export function createAdaptiveFetch(
  options: AdaptiveTransportOptions,
): ((input: RequestInfo | URL, init?: AdaptiveTransportRequestInit) => Promise<Response>) & {
  transport: AdaptiveTransport;
};

export { StorageRelayError } from './storage-relay.js';
