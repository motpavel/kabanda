export interface StorageRelayOptions {
  bootstrapUrl: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
  expectedAppId?: string;
  allowedStorageHosts?: string[];
}

export type StorageRelayDeliveryMode = 'polling' | 'object-trigger';

export interface StorageRelayUploadForm {
  url: string;
  fields: Record<string, string>;
}

export interface StorageRelayBootstrap {
  specversion: '1.0';
  app_id: string;
  updated_at: string;
  expires_at: string;
  expiresAt: number;
  delivery_mode: StorageRelayDeliveryMode;
  poll_interval_ms: number;
  request_timeout_ms: number;
  outbox_base_url: string;
  inbox_upload: StorageRelayUploadForm;
  wakeup_upload?: StorageRelayUploadForm;
}

export type StorageRelayRequestInit = Omit<RequestInit, 'body'> & {
  timeoutMs?: number;
  idempotencyKey?: string;
  body?: BodyInit | Record<string, unknown> | unknown[] | null;
};

export class StorageRelayError extends Error {
  code: string;
  status: number | null;
}

export class StorageRelayClient {
  constructor(options: StorageRelayOptions);
  loadBootstrap(options?: { force?: boolean; signal?: AbortSignal }): Promise<StorageRelayBootstrap>;
  fetch(input: RequestInfo | URL, init?: StorageRelayRequestInit): Promise<Response>;
}

export function createStorageRelayFetch(
  options: StorageRelayOptions,
): ((input: RequestInfo | URL, init?: StorageRelayRequestInit) => Promise<Response>) & {
  client: StorageRelayClient;
};

export function decryptResponseEnvelope(
  envelope: Record<string, unknown>,
  replyKey: Uint8Array,
): Promise<Record<string, unknown>>;
